﻿using System.Web.UI;

namespace pharmacyManagement.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}